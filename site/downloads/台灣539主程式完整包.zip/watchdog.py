#!/usr/bin/env python3
"""比較官方最新期別與公開手機頁；手機頁落後即失敗。"""
import hashlib, html, json, re, time, urllib.parse, urllib.request
import os
from datetime import datetime, time as clock_time
from cloud_pipeline import TAIPEI, expected_latest_date, fetch_latest
from tw539_ultra import build_single_supermodel, build_strict_publication_gate, load_draws, DATA

PAGE='https://pingshen670822.github.io/tw539-mobile-independent/system-health.json'
REPORT_ROOT='https://pingshen670822.github.io/tw539-mobile-independent/'
REPORT_PAGES=('index.html','backtest.html','review.html','history.html','models.html','health.html')
RESULT='https://pingshen670822.github.io/tw539-mobile-independent/latest-result.json'
VERSION='https://pingshen670822.github.io/tw539-mobile-independent/version.json'
SETTLEMENTS='https://pingshen670822.github.io/tw539-mobile-independent/published-settlements.jsonl'
MANIFEST='https://pingshen670822.github.io/tw539-mobile-independent/manifest.webmanifest'
WORKER='https://pingshen670822.github.io/tw539-mobile-independent/service-worker.js'
SYNC='https://pingshen670822.github.io/tw539-mobile-independent/mobile-sync.js'
DOWNLOAD=REPORT_ROOT+'downloads/'+urllib.parse.quote('台灣539主程式完整包.zip')
FAST_WATCHDOG=os.getenv('TW539_WATCHDOG_FAST','').lower() in ('1','true','yes')
PUBLIC_FETCH_RETRY_DELAYS=(0,1) if FAST_WATCHDOG else (0,2,6)
PUBLIC_FETCH_TIMEOUT_SECONDS=5 if FAST_WATCHDOG else 25
official=fetch_latest()
stamp=str(int(time.time()))
headers={'User-Agent':'TW539-ironlaw-watchdog/1.0','Cache-Control':'no-cache'}

def fetch_public(url):
    """有界重試公開頁，避免單次瞬時錯誤誤觸發修復或卡死。"""
    last=None
    for attempt,delay in enumerate(PUBLIC_FETCH_RETRY_DELAYS,1):
        if delay: time.sleep(delay)
        try:
            separator='&' if '?' in url else '?'
            req=urllib.request.Request(f'{url}{separator}t={stamp}-{attempt}',headers=headers)
            with urllib.request.urlopen(req,timeout=PUBLIC_FETCH_TIMEOUT_SECONDS) as response:
                body=response.read()
                if response.status!=200:
                    raise RuntimeError(f'狀態碼{response.status}')
                return response.status,response.headers.get_content_type(),body
        except Exception as exc:
            last=exc
    raise RuntimeError(f'公開頁連續{len(PUBLIC_FETCH_RETRY_DELAYS)}次讀取失敗：{url}：{last}') from last

def fetch_public_json(url):
    return json.loads(fetch_public(url)[2].decode('utf-8'))

health=fetch_public_json(PAGE)
result=fetch_public_json(RESULT)
version=fetch_public_json(VERSION)
if FAST_WATCHDOG:
    fast_errors=[]
    if str(health.get('latest_period'))!=str(official['period']): fast_errors.append('公開期別落後官方')
    if health.get('latest_draw_date')!=official['draw_date'] or not health.get('freshness_ok'): fast_errors.append('公開日期或新鮮度未通過')
    data_latest=result.get('data_latest') or {}
    if str(data_latest.get('period'))!=str(official['period']) or data_latest.get('date')!=official['draw_date']: fast_errors.append('公開結果落後官方')
    if str(version.get('latest_period'))!=str(official['period']) or version.get('latest_draw_date')!=official['draw_date']: fast_errors.append('手機版本落後官方')
    if fast_errors: raise SystemExit('即時自修檢查失敗：'+'；'.join(fast_errors))
    print(json.dumps({'即時自修檢查':'通過','官方期別':official['period'],'公開期別':health['latest_period']},ensure_ascii=False))
    raise SystemExit(0)
pages={}
for name in REPORT_PAGES:
    pages[name]=fetch_public(REPORT_ROOT+name)[2].decode('utf-8')
settlements=[json.loads(line) for line in fetch_public(SETTLEMENTS)[2].decode('utf-8').splitlines() if line.strip()]
manifest=fetch_public_json(MANIFEST)
worker=fetch_public(WORKER)[2].decode('utf-8')
sync=fetch_public(SYNC)[2].decode('utf-8')
download_status,download_type,download_body=fetch_public(DOWNLOAD)
public_icons={}
for name in ('icon-180.png','icon-192.png','icon-512.png','maskable-512.png'):
    status,content_type,body=fetch_public(REPORT_ROOT+'icons/'+name)
    public_icons[name]=(status,content_type,body[:24])
errors=[]
warnings=[]
if download_status!=200 or len(download_body)<100000 or download_type not in ('application/zip','application/x-zip-compressed','application/octet-stream'):
    errors.append('主程式完整壓縮包缺失或內容不完整')
now=datetime.now(TAIPEI)
deadline_active=now.time()>=clock_time(21,0) or now.time()<clock_time(6,0)
if deadline_active and official['draw_date']<expected_latest_date(now): warnings.append('開獎後三十分鐘官方資料仍未取得；立即自修並持續巡檢')
if str(health.get('latest_period'))!=str(official['period']): errors.append(f"公開期別 {health.get('latest_period')} != 官方 {official['period']}")
if health.get('latest_draw_date')!=official['draw_date']: errors.append(f"公開日期 {health.get('latest_draw_date')} != 官方 {official['draw_date']}")
if not health.get('freshness_ok'): errors.append('公開頁新鮮度未通過')
if not health.get('full_history_mode'): errors.append('公開頁不是100%全歷史模式')
if not health.get('history_database_sha256'): errors.append('公開頁缺資料庫指紋')
settlement_coverage=health.get('settlement_coverage') or {}
if (not health.get('settlement_coverage_complete') or settlement_coverage.get('missing_draws')!=0
        or settlement_coverage.get('accounted_draws')!=settlement_coverage.get('expected_draws')):
    errors.append('公開歷史結算仍有遺失資料')
for key in ('sync_completed_at','sync_delay_minutes','thirty_minute_repair_deadline','thirty_minute_deadline_met','deadline_policy_effective_draw_date','deadline_enforced_for_latest_draw','deadline_violation','deadline_recovered','self_repair_status','self_repair_count','last_public_verification_at','mobile_open_sync','pipeline_version','update_retry_policy','stability_monitor','latest_review_accounted','cloud_independent_update','local_computer_required','cloud_update_schedule','update_start_deadline_minutes','completion_deadline_minutes','watchdog_interval_minutes','upstream_failure_forces_repair','desktop_mobile_sync','desktop_mobile_shared_version'):
    if key not in health: errors.append('公開健康檔缺少自主修復欄位：'+key)
if not health.get('cloud_independent_update') or health.get('local_computer_required') is not False:
    errors.append('公開健康檔未確認關機後仍由雲端獨立更新')
if not health.get('desktop_mobile_sync') or not health.get('desktop_mobile_shared_version'):
    errors.append('公開健康檔未確認電腦版與手機版同版同步')
if (health.get('update_start_deadline_minutes')!=10 or health.get('completion_deadline_minutes')!=30
        or health.get('watchdog_interval_minutes')!=5 or not health.get('upstream_failure_forces_repair')):
    errors.append('公開健康檔未落實十分鐘啟動、三十分鐘完成與故障強制自修')
if health.get('deadline_enforced_for_latest_draw') and not health.get('thirty_minute_deadline_met',True):
    if health.get('freshness_ok') and health.get('deadline_recovered'):
        warnings.append('本期曾超過三十分鐘，但資料已補齊；保留逾時紀錄並繼續監控下一期')
    else:
        errors.append('本期超過三十分鐘且尚未完成同步')
data_latest=result.get('data_latest') or {}
if str(data_latest.get('period'))!=str(official['period']) or data_latest.get('date')!=official['draw_date']: errors.append('公開結果未對應官方最新期別')
ranked=result.get('ranked_top15') or []
single_supermodel=result.get('single_supermodel') or {}
if not ranked or result.get('single_candidate')!=single_supermodel.get('candidate'): errors.append('公開結果的超級獨支候選缺失')
strict=result.get('strict_publication_gate') or {}
try:
    local_supermodel=build_single_supermodel(
        load_draws(DATA),result.get('repeat_qualification') or [],data_latest.get('nums') or [])
    if single_supermodel!=local_supermodel or single_supermodel!=(result.get('backtest') or {}).get('single_supermodel'): errors.append('超級獨支多時間窗模型無法重現')
    expected_strict=build_strict_publication_gate(
        result.get('ranked_all') or [],result.get('number_diagnostics') or [],
        result.get('repeat_qualification') or [],data_latest.get('nums') or [],result.get('backtest') or {},single_supermodel)
    if strict!=expected_strict or strict!=(result.get('backtest') or {}).get('strict_publication_gate'): errors.append('嚴格發布守門無法重現')
except Exception as exc: errors.append('嚴格發布守門重算失敗：'+str(exc))
tiers=strict.get('tiers') or {};qualified=list(strict.get('qualified_numbers') or [])
expected_single=(tiers.get('single') or [None])[0]
if result.get('single_published')!=expected_single or result.get('published_predictions')!=tiers: errors.append('正式發布含未達標號碼或分級不同步')
if not strict.get('no_padding') or any((tiers.get(key) or [])!=qualified[:size] for key,size in (strict.get('requested_sizes') or {}).items() if key!='single'): errors.append('正式發布違反不足不補位')
single_break=result.get('single_repeat_break') or {}
if not single_break or 'rolling_review_consumed' not in single_break: errors.append('公開結果缺少每期未中檢討與單碼重複冷卻狀態')
ranked_all=result.get('ranked_all') or []
if len(ranked_all)!=39 or set(ranked_all)!=set(range(1,40)) or ranked!=ranked_all[:15]: errors.append('公開結果缺少開獎前完整39碼排序')
if len(result.get('number_diagnostics') or [])!=39 or result.get('single_selection_evidence')!=single_supermodel: errors.append('公開結果缺少超級獨支完整證據')
single_explanation=result.get('single_explanation') or {}
if (single_explanation.get('candidate')!=result.get('single_candidate')
        or single_explanation.get('unique') is not True or single_explanation.get('walk_forward')!=single_supermodel.get('walk_forward')
        or not single_explanation.get('derived_from_pre_draw_seal')):
    errors.append('公開結果缺少超級獨支完整運算來源')
seal=result.get('pre_draw_seal') or {}; sealed_payload=seal.get('sealed_payload') or {}
seal_hash=hashlib.sha256(json.dumps(sealed_payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
if seal.get('sha256')!=seal_hash or not seal.get('no_post_draw_substitution') or result.get('recalculation_fingerprint')!=seal_hash[:16]: errors.append('開獎前封存雜湊驗證失敗')
if sealed_payload.get('single_supermodel')!=single_supermodel: errors.append('開獎前封存缺少超級獨支證據')
selection=(result.get('weight_selection_diagnostics') or [{}])[0]
ensemble=result.get('production_ensemble_weights') or []
anchor_ensemble=result.get('anchor_ensemble_weights') or []
if selection.get('candidate_count')!=286 or selection.get('eligible_candidate_count')!=146 or selection.get('method')!='balanced_three_model_consensus_all_history_286_grid' or (selection.get('long_history_selection_window') or {}).get('samples',0)<1000: errors.append('開獎後沒有完成286組搜尋、146組均衡篩選或長歷史複驗')
if ensemble or len(anchor_ensemble)!=3 or len(selection.get('ensemble_members') or [])!=3: errors.append('公開結果仍錯用同質三模型，或缺少分散錨定模型')
overlap=result.get('previous_draw_overlap_audit') or {}
if overlap.get('method')!='model_score_with_repeat_qualification' or overlap.get('full_previous_draw_copied_into_top9') or set(data_latest.get('nums') or []).issubset(ranked[:9]): errors.append('公開結果仍整批複製上一期號碼或缺少連莊資格')
repeat_by_number={x.get('number'):x for x in (result.get('repeat_qualification') or [])}
for n in set(ranked[:9])&set(data_latest.get('nums') or []):
    if not (repeat_by_number.get(n) or {}).get('qualified'): errors.append(f'上一期號碼{int(n):02}未通過連莊資格卻列入前9')
    if not (repeat_by_number.get(n) or {}).get('repeat_backtest_pass'): errors.append(f'上一期號碼{int(n):02}個別連莊回測未達標卻列入前9')
excluded=set(result.get('forced_ticket_exclusions') or [])
if excluded!=set(range(1,40))-set(qualified) or any(set(ticket)&excluded for ticket in (result.get('tickets') or [])): errors.append('公開推薦牌組含未達標號碼')
coverage=result.get('history_coverage') or {}
if coverage.get('mode')!='all_available_history_for_every_prediction' or coverage.get('global_history_blend')!=1.0: errors.append('公開結果不是100%全歷史正式排名')
if coverage.get('database_sha256')!=health.get('history_database_sha256'): errors.append('公開結果與健康檔的資料庫指紋不同')
backtest=result.get('backtest') or {}
if 'ranking_direction_valid' not in backtest or 'bottom1_hits' not in backtest or 'bottom5_avg_hits' not in backtest or 'bottom9_avg_hits' not in backtest or 'rank10_15_avg_hits' not in backtest or 'top9_capture_rate' not in backtest or 'boundary_control_valid' not in backtest: errors.append('公開結果缺少高低分與前9邊界驗證')
if bool(backtest.get('ranking_direction_valid'))!=bool(health.get('ranking_direction_valid')): errors.append('公開結果與健康檔的排序方向不同步')
if backtest.get('rank10_15_avg_hits')!=health.get('rank10_15_avg_hits') or backtest.get('top9_capture_rate')!=health.get('top9_capture_rate') or bool(backtest.get('boundary_control_valid'))!=bool(health.get('boundary_control_valid')): errors.append('公開結果與健康檔的前9邊界狀態不同步')
if backtest.get('next_signed_weights')!=result.get('production_weights') or result.get('audit_weights')!=result.get('production_weights'): errors.append('公開主選與方向模型隔離回測權重不同')
rolling=result.get('rolling_weight_adjustment') or {}
if rolling.get('production_weights')!=result.get('production_weights') or rolling.get('production_ensemble_weights')!=ensemble or rolling.get('anchor_ensemble_weights')!=selection.get('ensemble_members') or rolling.get('updates')!=360 or rolling.get('method')!='full_history_consensus_with_35pct_direct_hit_and_shadow_change' or rolling.get('strategy_candidate_count')!=30 or rolling.get('strategy_selection_window')!=360 or rolling.get('strategy_consensus_member_count')!=5: errors.append('最新開獎錯誤沒有觸發全歷史方向共識、直接命中、單碼冷卻與資料變化影子驗證')
direct_gate=bool(backtest.get('direct_hit_full_rank_gate'))
if (not rolling.get('direct_hit_calibration_enabled') or rolling.get('direct_hit_window')!=360
        or rolling.get('direct_hit_ridge')!=10.0 or rolling.get('direct_hit_full_rank_blend')!=.35
        or bool(rolling.get('direct_hit_full_rank_gate'))!=direct_gate):
    errors.append('滾動修正未同步直接命中全排序校準')
if not rolling.get('single_repeat_break_enabled') or not rolling.get('single_repeat_break_gate') or rolling.get('single_repeat_break_current')!=single_break: errors.append('滾動修正未同步單碼重複冷卻與封存狀態')
if not rolling.get('data_change_enabled') or rolling.get('data_change_window')!=720 or rolling.get('data_change_ridge')!=1.0 or rolling.get('data_change_rank_blend')!=0.0 or rolling.get('data_change_preserve_front')!=5 or bool(rolling.get('data_change_gate'))!=bool(backtest.get('data_change_gate')): errors.append('滾動修正未同步每期資料變化影子驗證')
rate_selection=rolling.get('learning_rate_selection') or {}
if rate_selection.get('candidate_count')!=30 or rate_selection.get('learning_rate_candidate_count')!=6 or rate_selection.get('boundary_blend_candidate_count')!=5 or not rate_selection.get('holdout_not_used'): errors.append('舊邊界診斷未保持隔離')
if backtest.get('next_signed_weights')!=result.get('production_weights') or backtest.get('rolling_update_count')!=360: errors.append('隔離回測沒有重演方向模型逐期選擇')
if backtest.get('strategy_candidate_count')!=30 or backtest.get('strategy_selection_window')!=360 or backtest.get('strategy_consensus_member_count')!=5: errors.append('隔離回測缺少三十組方向模型、三百六十期選擇窗或五組權重共識')
if health.get('polarity_selection_window')!=360 or health.get('polarity_consensus_member_count')!=5: errors.append('公開健康檔未同步三百六十期五組權重共識')
direct_baseline=backtest.get('direct_hit_baseline') or {}
if (not backtest.get('direct_hit_calibration_enabled') or backtest.get('direct_hit_window')!=360
        or backtest.get('direct_hit_ridge')!=10.0 or backtest.get('direct_hit_full_rank_blend')!=.35):
    errors.append('直接命中全排序校準參數錯誤')
if not backtest.get('single_repeat_break_enabled') or backtest.get('single_repeat_break_cooldown')!=1 or not backtest.get('single_repeat_break_gate'): errors.append('單碼重複冷卻參數或上線守門錯誤')
if not backtest.get('data_change_enabled') or backtest.get('data_change_window')!=720 or backtest.get('data_change_ridge')!=1.0 or backtest.get('data_change_rank_blend')!=0.0 or backtest.get('data_change_preserve_front')!=5: errors.append('每期資料變化影子驗證參數錯誤')
if not backtest.get('data_change_gate'): warnings.append('每期資料變化校正未通過上線守門，正式排序已自動停用此模組')
for after,before in (('single_repeat_break_hits','single_repeat_break_baseline_hits'),('single_repeat_break_recent_54_hits','single_repeat_break_recent_54_baseline_hits'),('single_repeat_break_recent_120_hits','single_repeat_break_recent_120_baseline_hits')):
    if backtest.get(after,0)<backtest.get(before,0): errors.append('單碼重複冷卻拖累隔離命中')
direct_regressions=[]
for current,baseline,label in (
        (backtest,direct_baseline,'三百六十期'),
        ((backtest.get('recent_54') or {}),(backtest.get('direct_hit_baseline_recent_54') or {}),'最近五十四期'),
        ((backtest.get('recent_120') or {}),(backtest.get('direct_hit_baseline_recent_120') or {}),'最近一百二十期')):
    for metric,metric_label in (('top5_avg_hits','前五'),('top9_avg_hits','前九')):
        if current.get(metric,0)<baseline.get(metric,0):
            direct_regressions.append(label+metric_label)
if direct_gate!=(not direct_regressions):
    errors.append('直接命中全排序校準守門結果與回測數據不一致')
elif not direct_gate:
    warnings.append('直接命中全排序校準未通過上線守門，已自動回退五組方向共識：'+','.join(direct_regressions))
if (not health.get('direct_hit_calibration_enabled') or health.get('direct_hit_window')!=360
        or health.get('direct_hit_ridge')!=10.0 or health.get('direct_hit_full_rank_blend')!=.35
        or bool(health.get('direct_hit_full_rank_gate'))!=direct_gate):
    errors.append('公開健康檔未同步直接命中全排序校準')
if not health.get('single_repeat_break_enabled') or not health.get('single_repeat_break_gate') or health.get('single_repeat_break_current')!=single_break: errors.append('公開健康檔未同步單碼重複冷卻')
if not health.get('data_change_enabled') or health.get('data_change_window')!=720 or health.get('data_change_ridge')!=1.0 or health.get('data_change_rank_blend')!=0.0 or health.get('data_change_preserve_front')!=5 or bool(health.get('data_change_gate'))!=bool(backtest.get('data_change_gate')): errors.append('公開健康檔未同步每期資料變化影子驗證')
stability=backtest.get('anchor_stability') or {}
if stability.get('selected') not in ('穩定冠軍','每日挑戰者') or rolling.get('anchor_stability')!=stability or health.get('anchor_stability')!=stability or rolling.get('anchor_weights')!=result.get('production_anchor_weights') or health.get('production_anchor_weights')!=result.get('production_anchor_weights'): errors.append('穩定冠軍與每日挑戰模型守門未完整同步')
if not backtest.get('catastrophic_guard_enabled'): errors.append('公開結果未啟用災難失準保護')
if backtest.get('single_specialist_enabled'): errors.append('公開結果仍啟用已證明拖累的短窗單碼重排')
if backtest.get('catastrophic_guard_execution_enabled') or backtest.get('catastrophic_guard_application_count')!=0: errors.append('失準旋轉未保持只監測或曾改動正式排序')
full_scan=result.get('full_history_scan') or {}
if full_scan.get('samples')!=result.get('draw_count',0)-320: errors.append('公開結果的全歷史逐期掃描期數錯誤')
if full_scan.get('validation_eligible') and not full_scan.get('ranking_direction_valid'): warnings.append('可驗證的全歷史逐期排序方向未通過')
if str(version.get('latest_period'))!=str(official['period']) or version.get('latest_draw_date')!=official['draw_date']: errors.append('手機版本檔未同步官方最新期別')
if not settlements:
    errors.append('公開頁缺少每期命中檢討結算檔')
else:
    review=settlements[-1]
    if review.get('target_draw_date')!=official['draw_date'] or str(review.get('official_period'))!=str(official['period']): errors.append('最新命中檢討未對應官方最新期別')
    if review.get('review_status')=='completed_from_pre_draw_seal':
        if not single_break.get('rolling_review_consumed'): errors.append('已有開獎前封存檢討，但單碼重複冷卻未讀取該檢討')
        if len(review.get('actual_rankings') or [])!=5 or len(review.get('module_review') or [])!=len(result.get('production_weights') or {}): errors.append('最新命中檢討缺少實際排名或錯誤模組分析')
        expected_top5_hits=sorted(set(review.get('actual_numbers') or []).intersection(review.get('top5_published') or []))
        strict_review=review.get('publication_policy') in ('strict_no_padding_v1','mandatory_computed_single_strict_no_padding_v2')
        if ((strict_review and (not review.get('publication_no_padding') or len(review.get('top5_published') or [])>5))
                or (not strict_review and len(review.get('top5_published') or [])!=5)
                or sorted(review.get('top5_hits') or [])!=expected_top5_hits): errors.append('最新命中檢討缺少、補位或算錯前5命中資料')
        actual_boundary=sorted(x.get('number') for x in (review.get('actual_rankings') or []) if 10<=int(x.get('rank',99))<=15)
        if sorted(review.get('rank10_15_hits') or [])!=actual_boundary or review.get('boundary_review_status') not in ('triggered_and_recalculated','checked_no_rank_10_15_hit'): errors.append('最新命中檢討缺少第10至15名偏移檢查')
        if any(any(key not in module for key in ('boundary_actual_mean','false_top9_mean','boundary_discrimination_gap','boundary_error_flag')) for module in (review.get('module_review') or [])): errors.append('最新命中檢討缺少前9邊界逐模組比較')
        if not (review.get('data_integrity') or {}).get('no_post_draw_substitution'): errors.append('命中檢討未禁止開獎後換號')
        if not (review.get('rolling_adjustment') or {}).get('completed') or (review.get('rolling_adjustment') or {}).get('candidate_count')!=286 or (review.get('rolling_adjustment') or {}).get('boundary_parameter_candidate_count')!=30: errors.append('命中檢討後沒有完成286組權重與30組前9邊界重算')
        expected_condition=(len(review.get('top9_hits') or [])==0 and float(review.get('average_actual_rank') or 0)>=22)
        expected_guard=expected_condition and bool(backtest.get('catastrophic_guard_policy_recommends'))
        if bool(backtest.get('catastrophic_guard_current_condition'))!=expected_condition or bool(health.get('catastrophic_guard_current_condition'))!=expected_condition: errors.append('災難失準條件沒有依最新封存檢討同步')
        if bool(backtest.get('catastrophic_guard_current_trigger'))!=expected_guard or bool(health.get('catastrophic_guard_current_trigger'))!=expected_guard: errors.append('災難失準保護沒有依最新封存檢討同步啟動')
    elif review.get('review_status')=='recovery_no_pre_draw_seal':
        integrity=review.get('data_integrity') or {}
        if single_break.get('rolling_review_consumed'): errors.append('停擺缺口沒有開獎前封存資料，單碼重複冷卻不得偽稱已讀取命中檢討')
        if review.get('single_published') is not None or not review.get('review_accounted') or not integrity.get('no_fabricated_prediction'): errors.append('停擺缺口含事後補造預測或未完整登錄')
    else:
        errors.append('最新開獎未完成檢討或停擺缺口登錄')
    if not health.get('settled_previous') or not health.get('latest_review_accounted'): errors.append('健康檔沒有標示最新開獎已完成檢討或缺口登錄')
visible_pages={}
for name,page in pages.items():
    visible=re.sub(r'(?is)<(?:style|script)\b[^>]*>.*?</(?:style|script)>',' ',page)
    visible=html.unescape(re.sub(r'(?s)<[^>]+>',' ',visible))
    visible_pages[name]=visible
    english=sorted(set(re.findall(r'[A-Za-z][A-Za-z0-9_-]*',visible)))
    if english: errors.append(f'{name} 可見文字含英文：'+','.join(english))
    links=set(re.findall(r"href=['\"]\./([^'\"]+\.html)['\"]",page))
    if links!=set(REPORT_PAGES): errors.append(f'{name} 分頁導覽不完整')
    for term in ("rel='manifest'","rel='apple-touch-icon'","mobile-web-app-capable","apple-mobile-web-app-capable","id='install-app-button'",'安裝手機版',"id='manual-update-button'",'手動更新最新',"id='emergency-repair-button'",'當機立即修復','mobile-sync.js'):
        if term not in page: errors.append(f'{name} 缺少手機安裝條件：{term}')
home=visible_pages['index.html']; review_page=visible_pages['review.html']; backtest_page=visible_pages['backtest.html']; history_page=visible_pages['history.html']; models_page=visible_pages['models.html']; health_page=visible_pages['health.html']
if ('本期最強終極獨支' not in home or '本期其他鐵律號碼' not in home
        or '查看獨支強烈驗證與完整運算' not in home or '查看資料、排名、排除與連莊診斷' not in home
        or '超級獨支完整運算來源' not in home or '嚴格發布守門' not in home
        or '目前模型選擇證據' not in home or '六段時間隔離競賽' not in home
        or '隔離結果總表' not in home or '全球八家族軌跡融合複驗' not in home or '雙重隨機基準' not in home or '1中1' not in home
        or '終極獨支強烈驗證摘要' not in home or '不合格連莊前置排除' not in home
        or '不足不補位' not in home or '內部前十五診斷（非正式推薦）' not in home
        or (result.get('single_candidate') and f"{int(result['single_candidate']):02}" not in home)):
    errors.append('本期預測頁未完整顯示嚴格發布、運算來源或單碼冷卻狀態')
if any(term in home for term in ('最新一期命中結算','最後360期逐期走步回測','全歷史運算範圍','鐵律守門')): errors.append('本期預測頁混入其他分類資料')
if '最新一期命中結算' not in review_page or '開獎前前5正式預測' not in review_page or '前5命中資料' not in review_page or '錯誤模組與前9邊界逐項檢討' not in review_page or '第10至15名命中' not in review_page or '開獎後滾動權重重算' not in review_page or '禁止開獎後換號或補號' not in review_page: errors.append('開獎檢討分頁內容不完整')
if '超級獨支多時間窗隔離驗證' not in backtest_page or '全球軌跡融合與隨機基準複驗' not in backtest_page or '最近14期逐段隔離' not in backtest_page or '最後360期逐期走步回測' not in backtest_page or '直接命中全排序校準' not in backtest_page or '前5與前9任一關鍵區段退化即自動回退' not in backtest_page or '資料變化影子驗證' not in backtest_page or '單碼重複冷卻' not in backtest_page or '最近54期獨立觀察' not in backtest_page or '全歷史逐期一致性掃描' not in backtest_page: errors.append('回測驗證分頁內容不完整')
if ('歷史資料完整度' not in history_page or '尚缺官方資料' not in history_page or '官方期別' not in history_page
        or '開獎前封存實戰紀錄' not in history_page or '前5命中資料' not in history_page
        or '錯誤模組與前9邊界逐項檢討' in history_page): errors.append('歷史封存分頁內容不完整或混入逐項檢討')
if '超級獨支獨立模型' not in models_page or '全球八家族軌跡融合架構' not in models_page or '多階拖牌軌跡' not in models_page or '週期間隔危險率' not in models_page or '全球方法查證來源' not in models_page or '主程式完整壓縮包' not in models_page or '正式方向模型' not in models_page or '全系統重組' not in models_page or '五組正式權重共識' not in models_page or '直接命中全排序校準' not in models_page or '單碼重複冷卻' not in models_page or '資料變化影子驗證' not in models_page or '穩定冠軍與每日挑戰模型' not in models_page or '連莊資格驗算規格' not in models_page or '嚴格發布規格' not in models_page or '全歷史連莊率不低於12.82%' not in models_page: errors.append('模型說明分頁內容不完整')
if '超級獨支模型' not in health_page or '鐵律守門' not in health_page or '五組權重共識' not in health_page or '直接命中全排序校準' not in health_page or '單碼重複冷卻' not in health_page or '資料變化影子驗證' not in health_page or '手機同步' not in health_page or '開獎後更新與自主修復' not in health_page or '三十分鐘完成期限' not in health_page or '最遲啟動' not in health_page or '最遲完成' not in health_page or '主程式下載' not in health_page: errors.append('系統健康分頁內容不完整')
if any('低機率' in visible or '當期預測前九' in visible for visible in visible_pages.values()): errors.append('公開分頁仍含易誤解標示或事後回算內容')
expected_direction='排序方向通過' if backtest.get('ranking_direction_valid') else '排序方向未通過'
if expected_direction not in backtest_page or expected_direction not in health_page: errors.append('回測或健康分頁未照實顯示排序方向')
if manifest.get('id')!='./' or manifest.get('scope')!='./' or manifest.get('display')!='standalone' or not str(manifest.get('start_url','')).startswith('./index.html'):
    errors.append('公開手機安裝清單缺少獨立應用設定')
manifest_icons=manifest.get('icons') or []
if not {'192x192','512x512'}.issubset({item.get('sizes') for item in manifest_icons if item.get('type')=='image/png'}) or not any('maskable' in item.get('purpose','') for item in manifest_icons):
    errors.append('公開手機安裝清單缺少必要圖示')
for name,(status,content_type,raw) in public_icons.items():
    if status!=200 or content_type!='image/png' or raw[:8]!=b'\x89PNG\r\n\x1a\n': errors.append(f'公開手機安裝圖示無效：{name}')
for term in ('tw539-mobile-ironlaw-v9','mobile-sync.js','icons/icon-192.png','icons/icon-512.png','icons/maskable-512.png'):
    if term not in worker: errors.append(f'公開離線安裝快取缺少：{term}')
for term in ('beforeinstallprompt','appinstalled','install-app-button','手機版已安裝','AbortController','SYNC_TIMEOUT_MS=10000','syncInFlight'):
    if term not in sync: errors.append(f'公開手機安裝流程缺少：{term}')
for term in ('manualCloudSync','manual-update-button','caches.delete','latest-result.json','system-health.json','雲端資料已取得'):
    if term not in sync: errors.append(f'公開手動更新按鈕不是完整的一鍵雲端同步：{term}')
if errors: raise SystemExit('鐵律看門狗失敗：'+'；'.join(errors))
print(json.dumps({'看門狗':'通過','官方期別':official['period'],'公開期別':health['latest_period'],'全歷史':True,'命中檢討':'已完成或誠實登錄停擺缺口','滾動候選':286,'1中1主選':result['single_published'],'手機可安裝':True,'模型警報':warnings,'戰報可見英文':0},ensure_ascii=False))
